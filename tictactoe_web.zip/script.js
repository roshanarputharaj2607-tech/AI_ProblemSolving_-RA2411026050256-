let board = ["","","","","","","","",""];
let currentPlayer = "X";

const boardDiv = document.getElementById("board");

function render() {
    boardDiv.innerHTML = "";
    board.forEach((cell, i) => {
        const div = document.createElement("div");
        div.classList.add("cell");
        div.innerText = cell;
        div.onclick = () => move(i);
        boardDiv.appendChild(div);
    });
}

function move(i) {
    if (board[i] !== "") return;

    board[i] = "X";
    if (checkWin("X")) return alert("You win!");

    aiMove();

    render();
}

function aiMove() {
    let empty = board.map((v,i)=>v==""?i:null).filter(v=>v!=null);
    let move = empty[Math.floor(Math.random()*empty.length)];
    board[move] = "O";

    if (checkWin("O")) alert("AI wins!");
}

function checkWin(p) {
    const wins = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6]
    ];
    return wins.some(c => c.every(i => board[i] === p));
}

function resetGame() {
    board = ["","","","","","","","",""];
    render();
}

render();
